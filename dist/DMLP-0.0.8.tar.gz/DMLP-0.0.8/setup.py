from setuptools import setup, find_packages

VERSION = '0.0.8' 
DESCRIPTION = 'My first Python package'
LONG_DESCRIPTION = 'My first Python package with a slightly longer description'

setup(
       # 名称必须匹配文件名 'verysimplemodule'
        name="DMLP", 
        version=VERSION,
        author="YunhaoLi, Jieqi Liu",
        author_email="<youremail@email.com>",
        description=DESCRIPTION,
        long_description=LONG_DESCRIPTION,
        packages=find_packages(),
        install_requires=[
            "setuptools>=61.0",
            "nltk>=3.7",
            "numpy>=1.24.1",
            "tensorboardX>=2.6.2.2",
            "tqdm==4.66.1",
            "pudb==2023.1",
            "datasets==2.15.0",
            "boto3==1.33.10",
            "torch==2.2.0",
            "transformers==4.36.2"
            ], 
        keywords=['python', 'first package'],
        classifiers= [
            "Development Status :: 3 - Alpha",
            "Intended Audience :: Education",
            "Programming Language :: Python :: 2",
            "Programming Language :: Python :: 3",
            "Operating System :: MacOS :: MacOS X",
            "Operating System :: Microsoft :: Windows",
        ]
)